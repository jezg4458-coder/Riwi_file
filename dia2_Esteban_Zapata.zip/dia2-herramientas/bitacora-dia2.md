# Bitácora · Día 2 · Herramientas de desarrollo

- **Coder: Juan ESteban Zapata Garcia**
- **Fecha:18/10/2026**
- **TL: Johan Alexander Rivera Vasquez**

---

## 1. Mi entorno de desarrollo (Etapa 1)

- Versión de Ubuntu: 24.04.5 LTS
- Versión de Python:3
- ¿Dónde está instalado Python? (resultado de `which python3`): /usr/bin/python3
- Con mis palabras, la diferencia entre un compilador y un intérprete es: El interprete permite ejecutar y copiar, el compilador traduce a idioma de máquina en un ejecutable.
- ¿Qué pasó con la línea 4 de `hola.py` y por qué?: La línea 4 no se ejecutó porque el programa acabó en la línea 3, luego del error de sintaxis por las comillas faltantes.

| Herramienta | ¿Qué es? (sistema operativo, editor, intérprete, compilador o navegador) |
|---|---|
| Ubuntu | | Sistema operativo
| VS Code | | editor
| Python | | Interprete
| Chrome | | Navegador
| gcc | | Compilador

## 2. Reinstalación de VS Code (Etapa 2)

- ¿Cómo estaba instalado VS Code? (snap, .deb o no estaba): El sistema es nuevo y no lo tenía
- Comando que usé para desinstalarlo: sido apt remove code
- Comando que usé para instalarlo: sudo apt install code
- ¿Por qué es importante instalar desde la fuente oficial?: Por seguridad y para descargar la versión mas reciente.
- ¿Qué pasó con mi configuración al desinstalar? ¿Dónde vive?: La configuración queda guardada en el PC, aunque se borre code.

## 3. Perfiles y extensiones (Etapa 3)

- Con mis palabras, un perfil de VS Code es: Conjunto de extenciones o intérpretes.
- ¿Qué cambia en el Explorador entre un perfil y otro?: Cambian las características preferenciales y la forma en que te ayuda a visualizar el código
- ¿Por qué VS Code pregunta si confío en el publicador de una extensión?: Puede que por error se instale una copia de la extención original.

## 4. Duelo de perfiles (Etapa 4)

| Prueba | Perfil2-Basico | Perfil1-Pro |
|---|---|---|
| 1. Auto guardado | Hay que darle control s a cada rato | La información se guarda automática|
| 2. Auto Rename Tag |HAy que hacer todo manual|Automáticamente te muestra la etiqueta de cierre en HTML|
| 3. Error Lens |Sin esta extención solo se ve una línea roja en los errores| Te incluye sugerencias en la misma línea donde tienes el error| Auto rename siempre se tarda sus 39 ms en mi caso, vale la pena usar la función integrada en el editor, ya que de por si se creó para reemplazar la extención creada por terceros, segun he consultado.
| 4. Íconos |Las carpetas y archivos se ven mas planos | Se ven mas organizados los directorios y archivos|
| 5. Guías de indentación | | |
| 6. Extensiones corriendo | | |

**Reflexión**

1. ¿Noté diferencias en la experiencia de trabajo entre los dos perfiles? ¿Cuáles?
   - Sobre todo porque las etiquetes de HTML se auto completan. al instalar tambipen el python en VScode, hace sugerencias a medida que vas tipeando.
2. ¿Qué ventajas tiene usar múltiples perfiles en VS Code?
   - Como cada perfil con extenciones consume recursos, se puede tener un solo perfil para cada lenguaje o características necesarias, de acuerdo  a lo que se valla hacer. 
3. ¿Cómo influyen las extensiones en la productividad y en el rendimiento del editor?
   - Las extenciones consumen recursos, lo que puede generar lentitud en el editor si no se usan correctamente.
4. ¿Cuándo sería útil usar perfiles distintos en un entorno profesional? (dos ejemplos)
   - Cuando se va trabajar con 2 lenguajes diferentes o más. Puedp tener un perfin únicamente para desarrollo web y otro para funciones complejas con python.

## 5. Inspección y modificación (Etapa 5)

- Página que usé: https://cisco.com
- Cinco etiquetas que encontré y para qué sirven:
  1. <h1>Ésta etiqueta es para poner el título principal, solo 1 por página.</h1>
  2. <head>lleva información básica como el idioma y otros detalles que conectan con JS, no siempre tiene contenido visible.</head>
  3. <body>Conlleva casi todo el contenido y botones de la página.</body>
  4. <div>Funciona como organizador para mas elementos de una página.</div>
  5. <lang>Le dice a HTML el idioma en que se va mostrar la página.</lang>
- ¿Qué pasó con mis cambios al recargar y por qué?: Regresa la información normal de la página porque los cambios solamente se guardan en mi PC, se borran al refrescar la pestaña-
- Con mis palabras, el DOM es: Es la copia que se descarga en mi PC para visualizar la página, no es el archivo original.

## 6. La consola (Etapa 6)

| Operación | Mi predicción | Resultado real |
|---|---|---|
| `2 + 3` | | | 5
| `10 - 4 * 2` | | | 2
| `(10 - 4) * 2` | | | 12
| `10 / 4` | | | 2.5
| `10 % 3` | | | 0.3 y en el navegador 1
| `2 ** 8` | | | 100000000 y en el navegador 256
| `120000 * 0.19` | | | 22800 
| `365 * 24` | | |8760 

- ¿Por qué `0.1 + 0.2` no da exactamente `0.3`?: Esto ocurre porque los lenguajes modernos guardan los decimales en formato binario. Asumo que es por esto que en financiera siguen usando cobol y RPG, debido al tema de los redondeos.
- Errores o advertencias que encontré en la página (o "ninguno"):
- Diferencia entre un error y una advertencia: Error es cuando un elemento no se pudo ejecurar crpiticamente, la adventerncia es que incluye algo que podría no estar bien.

## 7. La red / Network (Etapa 7)

| Imagen | Formato | Tamaño | Tiempo | Código de estado |
|/home-icon-collaboration|svg|657kb|21.30ms|200 ok|
|nestle-logo-white|.svg|3.9kb|172ms|200ok|
|united-airlines-logo-white|.svg|5.5kb|371ms|200ok|
| | | | | |

| Experimento | Solicitudes | Transferido | Load |
|---|---|---|---|
| A. Sin caché |94 / 301 requests|648 kB / 3,903 kB transferred|695 kB / 12,186 kB resources|
| B. Con caché |85 / 275 requests|17.1 kB / 417 kB transferred|695 kB / 12,193 kB resources
|
| C. Red lenta |95 / 284 requests|95 / 284 requests|1,061 kB / 12,490 kB resources|

- Archivo más pesado de la página y su tipo: ES un video de 770kb el cual encontré desde la pestaña de "all".
- ¿Por qué la página cargó más rápido con caché?: porque recicla los elementos guardados en la memoria del equipo.
- ¿Por qué un desarrollador querría probar con una red lenta?: Para optimizar y verificar el comportamiento de la web en condiciones de lentitud
- ¿Qué haría para que una imagen pesada cargue más rápido?: Usar la página para que se guarde en cache, o en su defecto usar un internet 4g en adelante.

## 8. Dispositivos móviles (Etapa 8)

| Ancho (px) | Dispositivo | ¿Cambia el menú? | ¿Imágenes bien? | ¿Scroll horizontal? | Observación |
|---|---|---|---|---|---|
| 320 |responsive|Se ve todo mas largo|si|si|la página se adapta|
| 375 |responsive|un poco mas ancho|un poco|un poco|LOs menús interactivos funcionan bien|
| 768 |responsive|doble de alto que de ancho|si|si|la página se adapta bien|
| 1024 |responsive|ultra largo y delgado|si|si|la página si se adapta, está muy bien hecha|
| 1440 |responsive|similar al quad HD|si|si|todo funciona muy bien|

- ¿Por qué es importante probar varias resoluciones antes de entregar un proyecto?: Con esto se asegura que la mayoría de navegadores en los distintos tipos de despositivos se muestren correctamente, a demás de que funcionen los menus interactivos. 

## 9. Laboratorio de errores (Etapa 9)

| # | Tipo | ¿Dónde lo detecté? | Mensaje o síntoma | Causa | Solución aplicada |
|---|---|---|---|---|---|
| 1 |404|Línea 8 index.html|La carpeta CSS está en mayúsculas y en el archivo estaba minúscula la ruta| |se corrije nombre de la carpeta|
| 2 |boton no funciona|Uncaught TypeError|EL boton no hace nada al oprimir|el ID en js no coincide con el de html|se corrije id|
| 3 | | | | | |
| 4 | | | | | |

- Uno de los errores, descrito con detalle, y cómo lo resolví: Aunque sinceramente me apoyé un poco de la IA para hacer el proceso, me di la tarea de leer el código e implementar las deeptols para que me lleve a la ruta exacta donde se presentaban los errores.
- ¿Qué vi al pausar con el breakpoint?: Allí se evidencia los directorios de la web y archivos con código
- ¿Qué pasó al cambiar `visitas` por 99 y al borrarlo?: NO evidencie cambios sustanciales.
- ¿Para qué usan el localStorage las páginas reales? ¿Qué NO debería guardar ahí?: Es solo para guardar datos de preferencias, no se deben guardar datos censibles.
- Ancho exacto en el que se apilan las tarjetas y regla de CSS responsable: No se
- ¿Por qué no basta con mirar solo la consola para encontrar errores?: La consola es una guia inicial, pero los errores se corrigen directamente en el código de js o en html dependiendo del error en la terminal.

## 10. Comparación con Firefox (Etapa 10)

| Herramienta | Chrome: nombre y atajo | Firefox: nombre y atajo | Diferencia que noté |
|---|---|---|---|
| Inspeccionar HTML y CSS |El inspector de chrome es mas interactivo, como un VS code con extenciones|Firefox es mas táctico para navegar, literal me perdía en los menús de DevTools de Chrome, al inicio.|El de google más práctico, pero el moFirefox es mas limpio|
| Consola | No noté una diferencia substancial en las 2 consolas de los navegadores
| Red |Google me parece muy poco práctico para comenzar|Firefox tiene gráficos en la misma tabla que te muestra la información al activar o desactivar el cache|Me es mas fácil usar Firefox|
| Simulación de dispositivos | No noté una diferencia substancial en un navegador u otro
| Almacenamiento local |No noté una diferencia substancial en un navegador u otro
| Mensaje del error que reintroduje |Google te muestra directamente la sección de código con falla|En cambio, Firefox te adjunta un enlace a una paǵina para buscar información al resoecto|Me es mejor usa Firefox, hablando como principiante|

- Una característica de Firefox interesante o diferente a Chrome (qué es, para qué sirve y cómo la probé): He escuchado que firefox gestiona mejor los recursos que chrome, lo que personalmente noté en la DevTols es lo facil de encontrar las cosas desde Firefox, pero peude deberse también a que primero hicimos la práctica con Chrome

## 11. Reflexión final (Etapa 11)

- La herramienta que más voy a usar y por qué: El navegador, allí te dicta en tiempo real la ejecución de una web.
- Lo más difícil del día y cómo lo resolví:  Al inicio tuve problemas para correr esta máquina virtual, pero lo mas difícil fué deducir las fallas en la página, pero solo con solucionar 2 errores me funcionó, por ello decidí dejarlo ahí, a demas de la cuestión de tiempo.
- Las DevTools explicadas para alguien que no programa (3 líneas): Las DevTools son herramientas para desarrolladores, con las cuales puedes auditar fallos de las páginas web, o maximizar su funcionamiento.